import { Component, OnInit } from '@angular/core';
import { InvantoryService } from '../invantory.service';
import { NavController, AlertController } from '@ionic/angular';
@Component({
  selector: 'app-purchaseitem',
  templateUrl: './purchaseitem.page.html',
  styleUrls: ['./purchaseitem.page.scss'],
})
export class PurchaseitemPage implements OnInit {
  status:boolean;
  constructor(private storage:InvantoryService,private navcrt:NavController,private alertController:AlertController) {
    
   }
  private ListUser1 : any;
  ionViewWillEnter(){
    this.storage.GetAllUsers1().then((data: any) => {
      //console.log(data);
      this.ListUser1 = data;
      console.log("alfhia");
      console.log(this.ListUser1);
    // this.display();
    //  alert( " Show Data "+ this.ListUser1.productname+"\n");
    }, (error) => {
      console.log(error);
    })
  }
  ngOnInit() {
  }
  update(item){
    //alert(item.productname);
    this.storage.updateitem(item);
    //this.navcrt.navigateRoot("/update-purchase-item");

  }
//   flag;
//  delete(item,j){
//   //alert( "delete" + item.productname);
//   this.flag=!this.flag;
//   this.ListUser1.splice(j,1);
//   var id =item.id;
// // var id =item.id;
//   this.storage.Deletepurchaseitem(item,id).then( (data) => { 
//     console.log("Done"+data);
//   },(error) =>{
//    console.log("Not Done"+error);
// })
// } 
flag;
async delete(item,j){
  var id =item.id;
  const alert = await this.alertController.create({
    header: 'Confirm!',
    message: 'Are You Sure You Want To Delete Data ?',
    buttons: [
      {
        text: 'Cancel',
        role: 'cancel',
        cssClass: 'secondary',
        handler: (blah) => {
          console.log('Confirm Cancel: blah');
        }
      }, {
        text: 'Okay',
        handler: () => {
          this.flag=!this.flag;
          this.ListUser1.splice(j,1);
          this.storage.Deletepurchaseitem(item,id).then( (data) =>  { 
          this.flag=!this.flag;
            console.log("Done"+data);
          },(error) =>{
           console.log("Not Done"+error);
            })
        }
      }
    ]
  });
  await alert.present();
 }

}


