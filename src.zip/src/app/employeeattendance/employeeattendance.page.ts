import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employeeattendance',
  templateUrl: './employeeattendance.page.html',
  styleUrls: ['./employeeattendance.page.scss'],
})
export class EmployeeattendancePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
