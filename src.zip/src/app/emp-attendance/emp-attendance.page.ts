import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { InvantoryService } from '../invantory.service';

@Component({
  selector: 'app-emp-attendance',
  templateUrl: './emp-attendance.page.html',
  styleUrls: ['./emp-attendance.page.scss'],
})
export class EmpAttendancePage implements OnInit {
  private AttendanceEmployee :any;
  empalldata;
  ids;
  name;
  date;
  private Viewuser :any;
  constructor(private r:Router,private storage:InvantoryService) { }
back(){
  this.r.navigate(['/home']);
}
ionViewWillEnter(){
  this.empalldata=this.storage.returnempdata();
  this.ids=this.empalldata.id;
  this.name=this.empalldata.employeename;
  this.date=this.empalldata.date;

  this.storage.GetViewEmployee(this.name).then((data:any)=>{

    this.Viewuser=data;

  },(error)=>{
    console.log(error);
  })
}
show_employee(date,ename){
  console.log(date,ename);
  this.storage. Select_attendance(date,ename).then((data: any) => {
  console.log(data);
  this.Viewuser=data;
  console.log(data);
  }, (error) => {
  console.log(error);
  })
} 


ngOnInit() {
}
}









