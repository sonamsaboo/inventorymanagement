import { Component, OnInit } from '@angular/core';
import { InvantoryService } from '../invantory.service';
import { NavController } from '@ionic/angular';
import { ToastController } from '@ionic/angular';
import { Router } from '@angular/router';


@Component({
  selector: 'app-add-new-production',
  templateUrl: './add-new-production.page.html',
  styleUrls: ['./add-new-production.page.scss'],
})
export class AddNewProductionPage implements OnInit {

  constructor(private storage:InvantoryService,private nvert :Router,public toastController: ToastController) { }
  Pquantity;
  Pamount;

  n = new Date();
  y = this.n.getFullYear();
  m = this.n.getMonth()+1;
  d = this.n.getDate();
 
 mon  = this.m.toString();
 month  = parseInt(this.mon); 
 
 da;

  async  Add_producation(productname,producttype,quantity,unit,amount,date){
    this.Pquantity = parseInt(quantity);
    this.Pamount = parseInt(amount);
    
    if(this.month < 10){
      this.da = this.y+"-0"+this.m+"-"+this.d;
    }else{
     this.da = this.y+"-"+this.m+"-"+this.d;
    }

    console.log("Daa = "+ this.da );
    console.log("current Date= "+date)

    

      if(!productname){
        const toast = await this.toastController.create({
          message: 'Please Enter Product Name',
          duration: 2000
        });
        toast.present();
      }else if(!producttype){
        const toast = await this.toastController.create({
          message: 'Please Enter Product Type',
          duration: 2000
        });
        toast.present();
      }else if(!quantity){
        const toast = await this.toastController.create({
          message: 'Please Enter Product Quantity',
          duration: 2000
        });
        toast.present();
      }else if(!unit){
        const toast = await this.toastController.create({
          message: 'Please Enter Product Unit',
          duration: 2000
        });
        toast.present();
      }else if(!amount){
        const toast = await this.toastController.create({
          message: 'Please Enter Product Amount',
          duration: 2000
        });
        toast.present();
      }else if(!date){
        const toast = await this.toastController.create({
          message: 'Please Enter Product Date',
          duration: 2000
        });
        toast.present();
      }else{
        if(this.Pquantity>0){

          if(this.Pamount>0){

            if(date == this.da){
              this.storage.Add_Producation(productname,producttype,this.Pquantity,unit,this.Pamount,date).then( (data) => {  
              this.nvert.navigate(['/produce-iteam-list']);
            },(error) =>{ 
             console.log(error);
          })
        }else{

          const toast = await this.toastController.create({
            message: 'Please Select Current Date',
            duration: 2000
          });
          toast.present();
        }


            
          }else{
            const toast = await this.toastController.create({
              message: 'Please Enter Valid Amount',
              duration: 2000
            });
            toast.present();
          }

        }else{
          const toast = await this.toastController.create({
            message: 'Please Enter Valid Quantity',
            duration: 2000
          });
          toast.present();
        }

      }
    }

// takenToken;
// ionViewWillEnter(){
//  /*  this.takenToken = this.storage.getMobile();
//   if(!this.takenToken)
//   {
//     this.nvert.navigate(['/login-page']);
//   } */
//  }

UnitList
ionViewWillEnter(){
    this.storage.Show_Unit().then((data: any) => {
      console.log(data);
      this.UnitList = data;
    }, (error) => {
      console.log(error);
    }) 
   }
ngOnInit() {
}

}

