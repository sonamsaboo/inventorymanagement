import { Component, OnInit } from '@angular/core';
import { InvantoryService } from '../invantory.service';
import { NavController } from '@ionic/angular';
import { ToastController } from '@ionic/angular';

@Component({
  selector: 'app-register-page',
  templateUrl: './register-page.page.html',
  styleUrls: ['./register-page.page.scss'],
})
export class RegisterPagePage implements OnInit {

  constructor(private nvert:NavController,private Storage : InvantoryService,public toastController: ToastController) { }

  ngOnInit() {
  }
 re=/\w+@\w+\.\w+/;
 phoneno =/^\d*(?:\.\d{1,2})?$/;
  done;
  done2
  async Register(name,type,address,mobile,enail,pass){
    if(!name){
      const toast = await this.toastController.create({
        message: 'Please Enter Name',
        duration: 2000
      });
      toast.present();
    }else if(!type){
      const toast = await this.toastController.create({
        message: 'Please Enter Type',
        duration: 2000
      });
      toast.present();
    }else if(!address){
      const toast = await this.toastController.create({
        message: 'Please Enter Address',
        duration: 2000
      });
      toast.present();
    }
      else if(!mobile){
        const toast = await this.toastController.create({
          message: 'Please Enter Mobile Number',
          duration: 2000
        });
        toast.present();
      }
      else if(!enail){
        const toast = await this.toastController.create({
          message: 'Please Enter Email',
          duration: 2000
        });
        toast.present();
      }
      else if(!pass){
        const toast = await this.toastController.create({
          message: 'Please Enter Password',
          duration: 2000
        });
        toast.present();
      }
 
    else{
      this.done2 = this.phoneno.test(mobile)
      if(mobile.length==10&& mobile.indexOf('0')!==0 && this.done2 ){
        if(name.length>=3 && name.indexOf('0')!=="[0-9]"){
        this.done =  this.re.test(enail);
        if(!this.done){
          const toast = await this.toastController.create({
            message: 'Please Enter The Valid Email',
            duration: 2000
          });
          toast.present();
         }else{
          this.Storage.Register_User(name,type,address,mobile,enail,pass).then( (data) => {  
            this.nvert.navigateRoot("/login-page");
          },(error) =>{ 
           console.log(error);
        })
      }
      }else{
        const toast = await this.toastController.create({
          message: 'Please Enter The Valid Name',
          duration: 2000
        });
        toast.present();  
      }    
    }else{
      const toast = await this.toastController.create({
        message: 'Please Enter The Valid Mobile number',
        duration: 2000
      });
      toast.present();  
    } 
  }
  }
  }

