import { Component, OnInit } from '@angular/core';
import { InvantoryService } from '../invantory.service';
import { NavController } from '@ionic/angular';
import { ToastController } from '@ionic/angular';
import { Router } from '@angular/router';
@Component({
  selector: 'app-add-other-expenses',
  templateUrl: './add-other-expenses.page.html',
  styleUrls: ['./add-other-expenses.page.scss'],
})
export class AddOtherExpensesPage implements OnInit {
  amount;
  constructor( private Storage : InvantoryService,private nvert :Router,public toastController: ToastController) { }
  
  
  async  Add_Expenses(expensestype,expensestitle,expensesdate,expensesamount,expensesdetaile){
       this.amount = parseInt(expensesamount);


      if(!expensestype){
        const toast = await this.toastController.create({
          message: 'Please Enter Expenses Type',
          duration: 2000
        });
        toast.present();
      }else if(!expensestitle){
        const toast = await this.toastController.create({
          message: 'Please Enter Expenses Title',
          duration: 2000
        });
        toast.present();
      }else if(!expensesdate){
        const toast = await this.toastController.create({
          message: 'Please Enter Expenses Date',
          duration: 2000
        });
        toast.present();
      }else if(!expensesamount){
        const toast = await this.toastController.create({
          message: 'Please Enter Expenses Amount',
          duration: 2000
        });
        toast.present();
      }else if(!expensesdetaile){
        const toast = await this.toastController.create({
          message: 'Please Enter Expenses Detaile',
          duration: 2000
        });
        toast.present();
      }else{
        if(this.amount > 0){

          if(expensestitle.length <=20){
            this.Storage.Add_other_Expenses(expensestype,expensestitle,expensesdate,this.amount,expensesdetaile).then( async (data) => {  
              console.log("done 2"+data)
              const toast = await this.toastController.create({
                message: 'Data Added Successfully',
                duration: 2000
              });
              toast.present();
              this.nvert.navigate(['/other-expenses-list']);
            },(error) =>{ 
            console.log(error);
          })
            
          }else{
            const toast = await this.toastController.create({
              message: 'Enter Valid Title',
              duration: 2000
            });
            toast.present();
          }


         
        }else{
          const toast = await this.toastController.create({
          message: 'Please Enter Valid Amount',
          duration: 2000
        });
        toast.present();}
      }

    
  }
  ngOnInit() {
  }

}
