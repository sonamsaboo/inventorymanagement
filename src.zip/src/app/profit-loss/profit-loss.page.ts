import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { InvantoryService } from '../invantory.service';
import { ToastController } from '@ionic/angular';

@Component({
  selector: 'app-profit-loss',
  templateUrl: './profit-loss.page.html',
  styleUrls: ['./profit-loss.page.scss'],
})
export class ProfitLossPage implements OnInit {
From:string;
To:string ;
  constructor(private router:Router,private storage:InvantoryService,public toastController:ToastController) { }
async Date()
{
  if(!this.From|| !this.To ){
    const toast =await this.toastController.create({
      message:"Please Enter The Valid Details",
      duration: 2000,
    });
    toast.present();
  }
  else if(this.From>this.To){
    console.log("hyeeeeeeeee");
    const toast =await this.toastController.create({
      message:"Please Enter Correct Format",
      duration: 2000
    });
    toast.present();
    
  }
  else{
    this.router.navigate(['/profit-loss-status',{From:this.From,To:this.To}]);
  }
}

  ngOnInit() 
  { 
    
  }

}