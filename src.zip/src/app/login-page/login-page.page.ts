import { Component, OnInit } from '@angular/core';
import { NavController, LoadingController } from '@ionic/angular';
import { InvantoryService } from '../invantory.service';
import { ToastController } from '@ionic/angular';
@Component({
  selector: 'app-login-page',
  templateUrl: './login-page.page.html',
  styleUrls: ['./login-page.page.scss'],
})
export class LoginPagePage implements OnInit {

  // constructor(private nvert :NavController,private Storage :InvantoryService,public toastController: ToastController) { }
  // async  Login(mobile,pass){
  //         if(!mobile||!pass){
  //           const toast = await this.toastController.create({
  //             message: 'Please Enter The Valid Details',
  //             duration: 2000
  //           });
  //           toast.present();
  //           }else{
  //         this.Storage.Login_User(mobile,pass).then( (data) => {  
  //           this.nvert.navigateRoot("/home");
  //         },(error) =>{ 
  //         console.log(error);
  //       })
  //       }
  //     }
  constructor(private nvert :NavController,private Storage :InvantoryService,public toastController: ToastController,public loadingController: LoadingController) { }
  async  Login(mobile,pass){
          if(!mobile||!pass){
            const toast = await this.toastController.create({
              message: 'Please Enter The Valid Details',
              duration: 2000
            });
            toast.present();
            }else{
          this.Storage.Login_User(mobile,pass).then( async (data) => {
            const loading = await this.loadingController.create({
              message: 'Welcome',
              duration: 1000
            });
            await loading.present(); 
            this.nvert.navigateRoot("/home");
          },(error) =>{ 
          console.log(error);
        })
        }
      }
  ngOnInit() {
  }

}
