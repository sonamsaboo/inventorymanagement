import { Component, OnInit } from '@angular/core';
import { InvantoryService } from '../invantory.service';
import { ActivatedRoute } from '@angular/router';
import { ShowOtherExpensesPage } from '../show-other-expenses/show-other-expenses.page';

@Component({
  selector: 'app-stock-details',
  templateUrl: './stock-details.page.html',
  styleUrls: ['./stock-details.page.scss'],
})
export class StockDetailsPage implements OnInit {

  From="";
  producttype="";
  list:any;
  StockDetails:any;
  StockSoldDetails:any;
  totallist:any;
  fq;
  fa;
  sq;
  sa;
  finalq;
  finala;
  constructor(private storage:InvantoryService,private s:ActivatedRoute) {
    this.From=this.s.snapshot.paramMap.get('From');
    this.producttype=this.s.snapshot.paramMap.get('producttype');
   }

   ngOnInit(){
    this.storage.GetStockDetails(this.From,this.producttype).then((data: any) => {
      this.StockDetails=data;
  });
     /* this.storage.GetStockSoldDetails(this.From,this.producttype).then((data: any) => {
      this.StockSoldDetails=data;  */
     
 /* for(let i=0;i<this.StockDetails.length;i++){
  for(let j=0;j<this.StockSoldDetails.length;j++){
    if(this.StockDetails[i].productname==this.StockSoldDetails[j].productname)
    {
      this.fq=this.StockDetails[i].totalquantity;
      this.fa=this.StockSoldDetails[j].quantity;
      this.sq=this.StockDetails[i].netamount;
      this.sa=this.StockSoldDetails[j].totalamount;
      this.finalq=this.fq-this.fa;
      this.finala=this.sq-this.sa;
    }
  }
}
console.log("finalq="+this.finalq);
console.log("finala="+this.finala); */
}
}
