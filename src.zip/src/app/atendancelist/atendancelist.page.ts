import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { InvantoryService } from '../invantory.service';
import { ToastController } from '@ionic/angular';
import { AttendancePage } from '../attendance/attendance.page';

@Component({
  selector: 'app-atendancelist',
  templateUrl: './atendancelist.page.html',
  styleUrls: ['./atendancelist.page.scss'],
})
export class AtendancelistPage implements OnInit {
date;
private status1:boolean;
constructor(private r:Router,private storage:InvantoryService,private s:ActivatedRoute,private toastcontroller:ToastController) {
  /* this.date=this.s.snapshot.paramMap.get('date'); */
   /*  console.log(this.date); */
  
    this.date = this.storage.ReturnDate();
    
  
     }
    private ListUser : any;
    private Attendence:any;
    /* private count:any; */
    private attendancestatus:any;
    presentcount=0;
    absentcount=0;
    fetchpresent(){
        this.presentcount=0;
        this.absentcount=0;
       for( let i=0;i<this.ListUser.length;i++){ 
        if(this.ListUser[i].attendancestatus=="P"){
          this.presentcount++;
         }
        else if(this.ListUser[i].attendancestatus=="A"){
          this.absentcount++;
        }
        console.log(this.absentcount);
      }
    }
    allpresent(){
    for( let i=0;i<this.ListUser.length;i++){
       this.ListUser[i].attendancestatus="P";
         this.mycolor = 'warning'; 
  }  
  this.fetchpresent();
  }  
   allabsent(){
    for( let i=0;i<this.ListUser.length;i++){
       this.ListUser[i].attendancestatus="A";
         this.mycolor1 = 'danger'; 
  }  
  this.fetchpresent();
  } 
   ////nxt time
   fetchpresent1(){
    this.presentcount=0;
    this.absentcount=0;
   for( let i=0;i<this.Attendence.length;i++){ 
    if(this.Attendence[i].attendancestatus=="P"){
      this.presentcount++;
     }
    else if(this.Attendence[i].attendancestatus=="A"){
      this.absentcount++;
    }
    console.log(this.absentcount);
  }
}
allpresent1(){
for( let i=0;i<this.Attendence.length;i++){
   this.Attendence[i].attendancestatus="P";
     this.mycolor = 'warning'; 
}  
this.fetchpresent1();
}  
allabsent1(){
for( let i=0;i<this.Attendence.length;i++){
   this.Attendence[i].attendancestatus="A";
     this.mycolor1 = 'danger'; 
}  
this.fetchpresent1();
}   
    //back buton contact button 
    back(){
      this.r.navigate(['/attendance']);
    }
    //nextpage home icon
    nextpage(){
      this.r.navigate(['/home']);
    }
    mycolor = 'light';
    mycolor1 ='light';
   //button function call present or Absent
    status( attend:string,id:number,productname:string,date:string,j){
        if(attend=="present"){
        console.log("presenttttt");
         console.log(date); 
         console.log(id);
        this.ListUser[j].attendancestatus="P";
        this.mycolor = 'warning';
        this.fetchpresent();
  
        }
    else
  {
  console.log("Absent");
    this.ListUser[j].attendancestatus="A";
  this.mycolor1 = 'danger';
  this.fetchpresent(); 
    } 
  } 

  //Attendence
  status2( attend:string,id:number,productname:string,date:string,j){
    if(attend=="present"){
    console.log("presenttttt");
     console.log(date); 
     console.log(id);
    this.Attendence[j].attendancestatus="P";
    console.log( this.Attendence[j].attendancestatus="P");
    // this.mycolor = 'warning';
     this.fetchpresent1();

    }
else
{
console.log("Absent");
this.Attendence[j].attendancestatus="A";
console.log(this.Attendence);
// this.mycolor1 = 'danger';
 this.fetchpresent1(); 
} 
} 
  //save button navigate next page
   async save(){
    
    this.storage.attendancedata(this.ListUser,this.date).then(async (data)=>{
       console.log(this.ListUser); 
     const toast= await this.toastcontroller.create({
        message:"Attendance Recorded  Successfully Done",
        duration:500
      });
      toast.present();
     
   /*    console.log("done");
      alert("Sucessfully attendance recorded saved"); */
      this.r.navigate(['/attendance']);
    },(error)=>{
      console.log("Not Done"+error);
    })
  }

  async update(){
 //console.log(this.Attendence);
    this.storage.UpdateAttendence(this.Attendence).then(async (data)=>{
      console.log("enter updateeeeeeeeeeeeeeeee");
      console.log(data);
       //console.log(this.Attendence); 
     const toast= await this.toastcontroller.create({
        message:"Updated Attendance Recorded  Successfully",
        duration:500
      });
      toast.present();
     this.r.navigate(['/attendance']);
    },(error)=>{
      console.log("Not Done"+error);
    })
  }
  ngOnInit() {
    //Get all employeeee
      this.storage.GetAllEmployee().then((data: any) => {
        //console.log(data);
        this.ListUser = data;
    }, (error) => {
        console.log(error);
  
      })
      this.storage.ViewAttendence(this.date).then((data: any) => {
        console.log("Hiiiiiiiiiiiiiiiiiiiiiii");
        console.log(data);
        this.Attendence=data;
        if(this.Attendence.length>0){
          this.status1=true;

        }
        else{
          this.status1=false;
        }
       // this.ListUser = data;
    }, (error) => {
        console.log(error);
 })
     }
  }
  