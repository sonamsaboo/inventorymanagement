import { TestBed } from '@angular/core/testing';

import { InvantoryService } from './invantory.service';

describe('InvantoryService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: InvantoryService = TestBed.get(InvantoryService);
    expect(service).toBeTruthy();
  });
});
