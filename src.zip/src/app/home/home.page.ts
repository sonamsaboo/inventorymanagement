import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AttendancePage } from '../attendance/attendance.page';
import { NavController } from '@ionic/angular';
import { InvantoryService } from '../invantory.service';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
  private Compmey_Name : any;
  name;
constructor(private nvert :NavController,private Storage : InvantoryService){}

takenToken;
ionViewWillEnter(){

  this.takenToken = this.Storage.getMobile();
  if(!this.takenToken)
  {
    this.nvert.navigateRoot(['/mainpage']);
  }
  this.Storage.Comp_Name(this.takenToken).then((data: any) => {
    console.log(data);
    this.Compmey_Name = data;
	}, (error) => {
    console.log(error);
	})

 }

}
