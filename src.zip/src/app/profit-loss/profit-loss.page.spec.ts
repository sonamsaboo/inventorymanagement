import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProfitLossPage } from './profit-loss.page';

describe('ProfitLossPage', () => {
  let component: ProfitLossPage;
  let fixture: ComponentFixture<ProfitLossPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProfitLossPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProfitLossPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
