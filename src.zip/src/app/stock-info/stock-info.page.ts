import { Component, OnInit } from '@angular/core';
import { InvantoryService } from '../invantory.service';
import { Router } from '@angular/router';
import { ToastController } from '@ionic/angular';

@Component({
  selector: 'app-stock-info',
  templateUrl: './stock-info.page.html',
  styleUrls: ['./stock-info.page.scss'],
})
export class StockInfoPage implements OnInit {
  From:string;
  list:any;
  totallist:any;
  StockUsers:any;
  constructor(private storage:InvantoryService, private router:Router,private toastcontrol:ToastController) { }
ngOnInit(){}
 async show(From){
  if(!this.From){
    const toast=await this.toastcontrol.create({
    message:"Please Select Date",
    duration:2000
});
  toast.present();
}
   else{
    this.storage.GetStockInfo(this.From).then(async (data: any) => {
      if(data==null){
        console.log("hyeeeeeeeee");
        const toast =await this.toastcontrol.create({
          message:"No data Found",
          duration: 2000
        });
        toast.present();
      }else{
      this.StockUsers=data;
      console.log(data);
      }
      /* this.storage.GetStockpurchase(this.From).then((res: any) => {
        this.StockPurchase=res; */
    });
   }
 
} 
stockcard(producttype){
this.router.navigate(['/stock-details',{From:this.From,producttype:producttype}]);
}
}
