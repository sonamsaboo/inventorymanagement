import { Injectable } from '@angular/core';
import { SQLite, SQLiteObject } from '@ionic-native/sqlite/ngx';
import { Http } from '@angular/http';
import { NgFormSelectorWarning } from '@angular/forms';
import { NavController, ToastController } from '@ionic/angular';

@Injectable({
  providedIn: 'root'
})
export class InvantoryService {
private db: SQLiteObject;
private isOpen: boolean;
private totalproductionamount=0;
private productioncount=0;
private totalproductionquantity=0;
private totalpurchasequantity=0;
private totalpurchaseamount=0;
private purchasecount=0;

constructor(public http:Http,public storage:SQLite,private nvert :NavController,private toastcontroller:ToastController)
{ 
  //Chandrakant
if (!this.isOpen) {
  this.storage = new SQLite();
    this.storage.create({ name: "data.db", location: "default" }).then((db: SQLiteObject) => {
      this.db = db;
        // Add New Production -Chandu
        db.executeSql("CREATE TABLE IF NOT EXISTS addnewproduction (id INTEGER PRIMARY KEY AUTOINCREMENT, productname TEXT,  producttype TEXT, quantity TEXT,unit TEXT,amount TEXT,date TEXT)", []);
        //charuu create attendance
        db.executeSql("CREATE TABLE IF NOT EXISTS attendance (id INTEGER PRIMARY KEY AUTOINCREMENT, attendancestatus TEXT,  employeename TEXT,date TEXT)", []);
       // ALFHIA
        db.executeSql("CREATE TABLE IF NOT EXISTS addpurchaseitem (id INTEGER PRIMARY KEY AUTOINCREMENT, productname TEXT,  producttype TEXT, providerdetails TEXT,quantity TEXT,unit TEXT,totalamount TEXT,paidamount TEXT,date TEXT,details TEXT)", []);
       // ALFHIA
       db.executeSql("CREATE TABLE IF NOT EXISTS addsolditem (id INTEGER PRIMARY KEY AUTOINCREMENT, productname TEXT,  customername TEXT,producttype TEXT,quantity TEXT,totalamount TEXT,date TEXT,customerdetails TEXT)", []);
      //yogesh
       db.executeSql("CREATE TABLE IF NOT EXISTS addnewemployee (id INTEGER PRIMARY KEY AUTOINCREMENT, employeename TEXT, contact TEXT, email TEXT,salary TEXT,mode TEXT,address TEXT)", []);
      //unit
      db.executeSql("CREATE TABLE IF NOT EXISTS Addunit (id INTEGER PRIMARY KEY AUTOINCREMENT , unit TEXT)", []);
       //Add_other_Expenses -Chandu
       db.executeSql("CREATE TABLE IF NOT EXISTS addotherexpenses (id INTEGER PRIMARY KEY AUTOINCREMENT, expensestype TEXT,expensestitle TEXT,expensesdate TEXT,expensesamount TEXT,expensesdetaile TEXT)", []);
      //Register
      db.executeSql("CREATE TABLE IF NOT EXISTS addregisterdata (id INTEGER PRIMARY KEY AUTOINCREMENT, registername TEXT, type TEXT, address TEXT,mobile TEXT,email TEXT,password TEXT)", []);
   //stock
   db.executeSql("CREATE TABLE IF NOT EXISTS AddStock (id INTEGER PRIMARY KEY AUTOINCREMENT, productname TEXT, producttype TEXT, producequantity TEXT,purchasequantity TEXT,totalquantity TEXT,produceamount TEXT,purchaseamount TEXT,netamount TEXT,date TEXT)", []);
    })
  }
}
//unit
AddUnit(unit:string){
  return new Promise ((resolve, reject) => {
    let sql5 = "SELECT * FROM Addunit WHERE unit= ? ";
    this.db.executeSql(sql5, [unit]).then((data) => {
            if (data.rows.length > 0) {
                alert("Data Already inserted")        
            } 
            else{
              let sql = "INSERT INTO Addunit (unit) VALUES (?)";
              this.db.executeSql(sql, [unit]).then((data) =>{
                resolve(data);
              }, (error) => {
                reject(error);
            });
          }
  },(error) => {
  reject(error);
 });
});
}

//show
Show_Unit(){
  return new Promise ((resolve, reject) => {
    this.db.executeSql("SELECT * FROM Addunit ORDER BY id DESC ", []).then((data) => {
      let arrayUsers = [];
        if (data.rows.length > 0) {
          for (var i = 0; i < data.rows.length; i++) {
              arrayUsers.push({
                id: data.rows.item(i).id,
                unit: data.rows.item(i).unit
              });            
            }          
          }else{
            console.log("no data");
          }
          resolve(arrayUsers);
        }, (error) => {
          reject(error);
      })
  });
}



// Add 
//-----------------------------
ids; productname; producttype;producequantity;purchasequantity;
totalquantity;produceamount;purchaseamount;netamount;date;
 Tquan;
 Tnetmt;
  Add_Producation(productname:string, producttype:string, quantity:string,unit:string,amount:string,date:string){
    return new Promise ((resolve, reject) => {
     let sql1 = "SELECT * FROM AddStock WHERE productname = ? AND date = ? " ;
            this.db.executeSql(sql1, [productname,date]).then((data) => {
             if (data.rows.length > 0) {
            // this.ids = data[0];
            for (var i = 0; i < data.rows.length; i++) {  
              this.ids = data.rows.item(i).id; 
              console.log(data.rows.item(i));
              this.productname = data.rows.item(i).productname;
              this.producttype = data.rows.item(i). producttype;
              this.producequantity = data.rows.item(i).producequantity;
              this.purchasequantity =data.rows.item(i).purchasequantity;
              this.produceamount =data.rows.item(i).produceamount;
              this.purchaseamount = data.rows.item(i).purchaseamount; 
              console.log("purchaseamount ="+this.purchaseamount);
              this.date = data.rows.item(i).date;
          }
          this.producequantity = this.producequantity+ parseInt(quantity) ;
          this.produceamount = this.produceamount+parseInt(amount);
          this.totalquantity = parseInt(this.producequantity)+parseInt(this.purchasequantity) ;
          this.netamount = parseInt(this.produceamount)+parseInt(this.purchaseamount);
          
          console.log("producequantity ="+this.producequantity);
          console.log("produceamount ="+this.produceamount);
          console.log("totalquantity ="+this.totalquantity);
          console.log("this.netamount ="+this.netamount);

         let sql8 = "UPDATE AddStock SET productname = ?, producttype =?, producequantity =?,totalquantity =?,produceamount =?,netamount= ?,date =? WHERE id= ? ";
         this.db.executeSql(sql8,[productname,producttype, this.producequantity,this.totalquantity,this.produceamount,this.netamount,date,this.ids]).then((data) =>{
         console.log("Update done");
         console.log(data);
           resolve(data);
          }, (error) => {
          reject(error);
        });        
     }else{
    
    let sql = "INSERT INTO AddStock (productname , producttype , producequantity ,totalquantity ,produceamount ,netamount ,date) VALUES (?, ?, ?,?,?,?,?)";
      this.db.executeSql(sql, [productname, producttype, quantity,quantity,amount,amount,date]).then((data) =>{
      console.log("insert Done");
      console.log(data);
    resolve(data);
     },(error) => {
     reject(error);
    });	
    }(error) => {
   reject(error);
  }
  });
      let sql = "INSERT INTO addnewproduction (productname, producttype, quantity,unit,amount,date) VALUES (?, ?, ?,?,?,?)";
        this.db.executeSql(sql, [productname,producttype,quantity,unit,amount,date]).then((data) =>{
          console.log("Chandu Done" + data);
          console.log(data);
          resolve(data);
        }, (error) => {
          reject(error);
      }); 
  });
  }

// Add_other_Expenses -Chandu
Add_other_Expenses(expensestype :string,expensestitle:string,expensesdate:string,expensesamount :string,expensesdetaile:string){
   return new Promise ((resolve, reject) => {
    let sql = "INSERT INTO addotherexpenses (expensestype,expensestitle,expensesdate,expensesamount,expensesdetaile) VALUES (?, ?, ?,?,?)";
    this.db.executeSql(sql, [expensestype,expensestitle,expensesdate,expensesamount,expensesdetaile]).then((data) =>{
      resolve("done 1"+data);
    }, (error) => {
      reject(error);
    });
  });
}

// Show Producation List -Chandu
Show_All_Production(){
  return new Promise ((resolve, reject) => {  
    this.db.executeSql("SELECT * FROM addnewproduction ORDER BY id DESC ", []).then((data) => { 
      let arrayUsers = [];
      if (data.rows.length > 0) {
        for (var i = 0; i < data.rows.length; i++) {
          arrayUsers.push({
            id: data.rows.item(i).id,
            productname: data.rows.item(i).productname,
            producttype: data.rows.item(i).producttype,
            quantity: data.rows.item(i).quantity,
            unit: data.rows.item(i).unit,
            amount: data.rows.item(i).amount,
            date: data.rows.item(i).date 
          });             
        }          
      }
      resolve(arrayUsers);
    }, (error) => {
      reject(error);
    })
  })
}

// Get Other Expenses -Chandu
Select_Other_Exp(date1){
  return new Promise ((resolve, reject) => { 
    let sql5 = "SELECT * FROM addotherexpenses WHERE expensesdate = ? ";
      this.db.executeSql(sql5, [date1]).then(async (data) => {
        let arrayUsers = [];
        if (data.rows.length > 0) {
          for (var i = 0; i < data.rows.length; i++) {
            arrayUsers.push({
              id: data.rows.item(i).id,
               expensestype: data.rows.item(i).expensestype,
              expensestitle: data.rows.item(i).expensestitle,
              expensesdate: data.rows.item(i).expensesdate,
              expensesamount: data.rows.item(i).expensesamount,
              expensesdetaile: data.rows.item(i).expensesdetaile
            });            
          }          
        }else{
          const toast = await this.toastcontroller.create({
            message: 'No Data Found',
            duration: 2000
          });
          toast.present();
        }
        resolve(arrayUsers);
      }, (error) => {
        reject(error);
    })
  });
}

Show_All_Expenses(){
  return new Promise ((resolve, reject) => {
    this.db.executeSql("SELECT * FROM addotherexpenses ORDER BY id DESC  ", []).then((data) => {
      let arrayUsers = [];
        if (data.rows.length > 0) {
          for (var i = 0; i < data.rows.length; i++) {
              arrayUsers.push({
                id: data.rows.item(i).id,
                 expensestype: data.rows.item(i).expensestype,
                expensestitle: data.rows.item(i).expensestitle,
                expensesdate: data.rows.item(i).expensesdate,
                expensesamount: data.rows.item(i).expensesamount,
                expensesdetaile: data.rows.item(i).expensesdetaile
              });            
            }          
          }else{
            console.log("no data");
          }
          resolve(arrayUsers);
        }, (error) => {
          reject(error);
      })
  });
}
  
// //yogesh
Addemployee(employeename: string, contact:number, email:string,salary:number,mode:string,address:string){
  return new Promise ((resolve, reject) => {
    let sql5="SELECT * from addnewemployee WHERE contact = ? AND email = ? ORDER BY id DESC ";
    this.db.executeSql(sql5, [contact,email]).then(async (data)=>{
      if(data.rows.length>0){
        const toast = await this.toastcontroller.create({
                    message: 'Data already added.',
                    duration: 2000
                  });
                  toast.present();;
      }else{ let sql = "INSERT INTO addnewemployee (employeename,contact,email,salary,mode,address) VALUES (?, ?, ?,?,?,?)";
      const toast = await this.toastcontroller.create({
                  message: 'Data add Successfully.',
                  duration: 2000
                });
                toast.present();
      this.db.executeSql(sql, [employeename,contact,email,salary,mode,address]).then((data) =>{
        
        resolve(data);
      }, (error) => {
       
        reject(error);
      });
    }
    }) 
   
  });
 }

//chandu
Delid; Delproducequantity; Deltotalquantity;
Delproduceamount; Delnetamount; Deldate;
Delete_Producation(item,id){
  var prdnm =item.productname;
  var dat = item.date;
  var qunty = item.quantity;
  var amt = item.amount;
  return new Promise ((resolve, reject) => {  
	let sql1 = "SELECT id, producequantity ,totalquantity ,produceamount ,netamount FROM AddStock WHERE productname = ? AND date = ? ";
	this.db.executeSql(sql1, [prdnm,dat]).then((data) => {
          if (data.rows.length > 0) {
              for (var i = 0; i < data.rows.length; i++) {
                console.log(data.rows.item(i));
                  this.Delid = data.rows.item(i).id;
                  this.Delproducequantity = data.rows.item(i).producequantity;
                  this.Deltotalquantity = data.rows.item(i).totalquantity;
                  this.Delproduceamount = data.rows.item(i).produceamount;
                  this.Delnetamount = data.rows.item(i).netamount;
                  this.Deldate=data.rows.item(i).date             
              }
              console.log("id ="+this.Delid,this.Delproducequantity, this.Delnetamount); 

              this.Delproducequantity =  this.Delproducequantity - qunty;
              this.Deltotalquantity = this.Deltotalquantity- qunty;
              this.Delproduceamount =  this.Delproduceamount-amt;
              this.Delnetamount = this.Delnetamount - amt;

              console.log( "Delproducequantity"+this.Delproducequantity);
              console.log( "Deltotalquantity"+this.Deltotalquantity);
              console.log( ".Delproduceamount"+this.Delproduceamount);
              console.log( "Delnetamount"+this.Delnetamount);

              let sql8 = "UPDATE AddStock SET producequantity =? ,totalquantity = ?,produceamount =? ,netamount =? WHERE id= ? ";
              this.db.executeSql(sql8,[this.Delproducequantity, this.Deltotalquantity,this.Delproduceamount,this.Delnetamount,this.Delid]).then((data) =>{
              console.log("Update done"+data);
                resolve(data);
               }, (error) => {
               reject(error);
             });
   
          }else{
      }
      resolve(data);
      },(error) => {
          reject(error);
    })
	
	//---------------
	let sql2 = "DELETE FROM addnewproduction  WHERE id = ?";
      this.db.executeSql(sql2,[id]).then((data) =>{ 
            resolve(data);
          }, (error) => {
            reject(error);
          });
	});
	
	}

 //chandu
GetAllUsers(date1,date2){
    return new Promise ((resolve, reject) => {
      let sql5 = "SELECT * FROM addnewproduction WHERE date BETWEEN ? AND ? ORDER BY id DESC ";
        this.db.executeSql(sql5, [date1,date2]).then((data) => {
          console.log("Data" +data);
          let arrayUsers = [];
          if (data.rows.length > 0) {
            for (var i = 0; i < data.rows.length; i++) {
              arrayUsers.push({
                id: data.rows.item(i).id,
                productname: data.rows.item(i).productname,
                producttype: data.rows.item(i).producttype,
                quantity: data.rows.item(i).quantity,
                unit: data.rows.item(i).unit,
                amount: data.rows.item(i).amount,
                date: data.rows.item(i).date
              });            
            }          
          }
          resolve(arrayUsers);
        }, (error) => {
          reject(error);
     })
  });
}
// Register user
Register_User(registername, type, address,mobile,email,password){
  return new Promise ((resolve, reject) => {
  let sql5 = "SELECT * FROM addregisterdata WHERE mobile = ? ";
  this.db.executeSql(sql5, [mobile]).then((data) => {
          if (data.rows.length > 0) {
              alert("Mobile Nomber Already Register")        
          }
      else{
        let sql10 = "INSERT INTO addregisterdata (registername, type, address,mobile,email,password) VALUES (?, ?, ?,?,?,?)";
        this.db.executeSql(sql10, [registername, type, address,mobile,email,password]).then(async(data) =>{
          const toast = await this.toastcontroller.create({
            message: 'Sucessfully Register!!!!!',
            duration: 2000
          });
          toast.present();
          console.log("Done22"+data)
        resolve(data);
        },(error) => {
          reject(error);
        });
      
        }
         
      },(error) => {
          reject(error);
    })
  });
}

// Login User 
 Login_User(mobile,password){
  console.log("Data2"+mobile,password);
	return new Promise (async (resolve, reject) => {
  let sql11 = "SELECT * FROM addregisterdata WHERE mobile = ? AND password = ? ";
  const toast = await this.toastcontroller.create({
    message: 'Login Sucessfully !!!!!',
    duration: 2000
  });
  toast.present();  
	this.db.executeSql(sql11, [mobile,password]).then(async(data) => {
  
    if (data.rows.length > 0) {
         
          this.SaveMobile(mobile);
          resolve(data);      
        }
	else{
      const toast = await this.toastcontroller.create({
        message: 'Please Enter The Correct Mobile Number And Password!!!!!!',
        duration: 2000
      });
      toast.present();
      } 
      
		},(error) => {
        reject(error);
      })
	});
}

Comp_Name(mobile){
    return new Promise ((resolve, reject) => {
      console.log(mobile);
    let sql11 = "SELECT * FROM addregisterdata WHERE mobile = ? ";
    this.db.executeSql(sql11, [mobile]).then((data) => {
            console.log("Name Done" +data);
            let arrayUsers = [];
            if (data.rows.length > 0) {
              for (var i = 0; i < data.rows.length; i++) {
                arrayUsers.push({
                  id: data.rows.item(i).id,
                  registername: data.rows.item(i).registername 
                });            
              }          
            }
            resolve(arrayUsers);
          }, (error) => {
            reject(error);
       })
  });
}

SaveMobile(mobile){
  localStorage.setItem('MobNo',mobile);
}
getMobile(){
  return localStorage.getItem('MobNo');
}

//-----------------------

AttDate
SetDate(Date){
this.AttDate = Date;
}
ReturnDate(){
  return this.AttDate;
}
//charu get attendance data
attendancedata(ListUser,date){
  
  return new Promise ((resolve, reject) => {
    for(let i=0;i<ListUser.length;i++){
    let sql = "INSERT INTO attendance (attendancestatus,employeename,date) VALUES (?, ?, ?)";
    this.db.executeSql(sql, [ListUser[i].attendancestatus,ListUser[i].employeename,date]).then((data) =>{
      resolve(data);
      console.log("done");
    }, (error) => {
      reject(error);
    });
   }
 });
}
//update charu
UpdateAttendence(Attendence){
  console.log(Attendence);
  return new Promise ((resolve, reject) => {
    for(let i=0;i<Attendence.length;i++){
 
     let sql8 = "UPDATE attendance SET attendancestatus = ?,employeename = ?, date = ? where id = ?";
       this.db.executeSql(sql8,[Attendence[i].attendancestatus,Attendence[i].employeename,Attendence[i].date, Attendence[i].id]).then((data) =>{
           resolve(data);
         }, (error) => {
       reject(error);
     });
    }
   });
  
 }
  //Yogesh Get Employee Query
GetAllEmployee(){
  return new Promise ((resolve, reject) => {
    this.db.executeSql("SELECT * FROM addnewemployee ORDER BY id DESC ", []).then((data) => {
        let arrayUsers = [];
          if (data.rows.length > 0) {
              for (var i = 0; i < data.rows.length; i++) {
                    arrayUsers.push({
                      id: data.rows.item(i).id,
                      employeename: data.rows.item(i).employeename,
                      contact: data.rows.item(i).contact,
                      email: data.rows.item(i).email,
                      salary: data.rows.item(i).salary,
                      mode: data.rows.item(i).mode,
                      address: data.rows.item(i).address  
                  }); 
                }          
              }
          resolve(arrayUsers);
        }, (error) => {
         reject(error);
     })
  })
}


//create user

ids1; 
productname1;
producttype1;
producequantity1;
purchasequantity1;
totalquantity1;
produceamount1;
purchaseamount1;
netamount1; 
date1;
Tquan1;
Tnetmt1;
CreateUser1(productname: string, producttype:string,providerdetails:string,quantity:string,unit:string,totalamount:string,paidamount:string,date:string,details:string)
{
  return new Promise ((resolve, reject) => {

   let sql1 = "SELECT * FROM AddStock WHERE productname = ? AND date = ? " ;
         console.log("asdfwer");
   this.db.executeSql(sql1, [productname,date]).then((data) => {        
        if (data.rows.length > 0) 
        {
          this.ids1 = data[0];
          for (var i = 0; i < data.rows.length; i++) {  
            this.ids1 = data.rows.item(i).id; 
            console.log(data.rows.item(i));
            this.productname1 = data.rows.item(i).productname;
            this.producttype1 =  data.rows.item(i). producttype;
            this.producequantity1= data.rows.item(i).producequantity;
            this.purchasequantity1 = data.rows.item(i).purchasequantity;
            /* this.totalquantity = parseInt(data.rows.item(i).totalquantity); */
            this.produceamount1 =  data.rows.item(i).produceamount;
            this.purchaseamount1 =  data.rows.item(i).purchaseamount; 
            /* this.netamount = parseInt(data.rows.item(i).netamount); */
            this.date1 = data.rows.item(i).date;
          }
          this.purchasequantity1 =  this.purchasequantity1+ parseInt(quantity) ;
        this.purchaseamount1 =this.purchaseamount1+parseInt(totalamount);
        this.totalquantity1 = parseInt(this.producequantity1)+parseInt(this.purchasequantity1);
        this.netamount1 =parseInt(this.produceamount1)+parseInt(this.purchaseamount1);

        console.log("purchaseqname ="+this.productname1); 
        console.log("purchatype ="+this.producttype1);
        console.log(" ="+this.producequantity1);
        console.log("purchasequantity ="+this.purchasequantity1);
        console.log("purchaseamount ="+this.purchaseamount1);
        console.log("totalquantity ="+this.totalquantity1);
        console.log("this.netamount ="+this.netamount1);
  
       let sql8 = "UPDATE AddStock SET productname = ?, producttype =?, producequantity =?,totalquantity =?,produceamount =?,netamount= ?,date =? WHERE id= ? ";
       this.db.executeSql(sql8,[productname,producttype, this.purchasequantity1,this.totalquantity1,this.purchaseamount1,this.netamount1,date,this.ids1]).then((data) =>{
       console.log("Update done"+data);
         resolve(data);
        }, (error) => {
        reject(error);
      });        
  }
   else{
  
  let sql1 = "INSERT INTO AddStock (productname , producttype , purchasequantity ,totalquantity ,purchaseamount ,netamount ,date) VALUES (?, ?, ?,?,?,?,?)";
    this.db.executeSql(sql1, [productname, producttype, quantity,quantity,totalamount,totalamount,date]).then((data) =>{
    console.log("insert Done" + data);
  resolve(data);
   },(error) => {
   reject(error);
  });	
  (error) => {
 reject(error);
}
   }
    let sql = "INSERT INTO addpurchaseitem (productname,producttype,providerdetails,quantity,unit,totalamount,paidamount,date,details) VALUES (?, ?, ?,?,?,?,?,?,?)";
       // alert(productname+""+producttype+""+providerdetails+""+quantity+""+unit+""+totalamount+""+paidamount+""+date+""+details+"");
        this.db.executeSql(sql, [productname,producttype,providerdetails,quantity,unit,totalamount,paidamount,date,details]).then((data) =>{  
         console.log("insert ho gaya");
          console.log(data);
          resolve(data);
        }, (error) => {
          reject(error);
     }); 
    });
  });
}
  
    // Alfhia AddSold Query 
CreateUser2(productname: string,customername:string,producttype:string,quantity:string,totalamount:string,date:string,customerdetails:string){
  return new Promise ((resolve, reject) => {
      let sql = "INSERT INTO addsolditem (productname,customername,producttype,quantity,totalamount,date,customerdetails) VALUES (?, ?, ?,?,?,?,?)";
        this.db.executeSql(sql, [productname,customername,producttype,quantity,totalamount,date,customerdetails]).then((data) =>{  
          resolve(data);
          console.log("inserted done");
        }, (error) => {   
          reject(error);
       });
   });  
}  
    
   //Alfiya Get Purchase Item 
GetAllUsers1(){
   return new Promise ((resolve, reject) => {
        this.db.executeSql("SELECT * FROM addpurchaseitem ORDER BY id DESC ", []).then((data) => {
          let arrayUsers = [];
          if (data.rows.length > 0) {
            for (var i = 0; i < data.rows.length; i++) {
              arrayUsers.push({
                id: data.rows.item(i).id,
                productname: data.rows.item(i).productname,
                producttype: data.rows.item(i).producttype,
                providerdetails: data.rows.item(i).providerdetails,
                quantity: data.rows.item(i).quantity,
                unit: data.rows.item(i).unit,
                totalamount: data.rows.item(i).totalamount,
                paidamount: data.rows.item(i).paidamount,
                date: data.rows.item(i).date,
                details: data.rows.item(i).details
              });            
            }          
          }
          resolve(arrayUsers);
        }, (error) => {
          reject(error);
      });
  });
}
//Get Sold items
GetAllUsers2(){
    return new Promise ((resolve, reject) => {
      this.db.executeSql("SELECT * FROM addsolditem ORDER BY id DESC ", []).then((data) => {
        let arrayUsers = [];
        if (data.rows.length > 0) {
          for (var i = 0; i < data.rows.length; i++) {
            arrayUsers.push({
              id: data.rows.item(i).id,
              productname: data.rows.item(i).productname,
              customername: data.rows.item(i).customername,
              producttype: data.rows.item(i).producttype,
              quantity: data.rows.item(i).quantity,
              // unit: data.rows.item(i).unit,
              totalamount: data.rows.item(i).totalamount,
              // paidamount: data.rows.item(i).paidamount,
              date: data.rows.item(i).date,
              customerdetails: data.rows.item(i).customerdetails
            });            
          }          
        }
        resolve(arrayUsers);
      }, (error) => {
        reject(error);
      })
    }) 
}
  //ALFHIA

  
updatedata1;
updateitem(item){
    this.updatedata1 =item;
  }
Returnupdatedata(){
    return this.updatedata1;
} 

//update
  


purchaseEdit_id;
purchaseEdit_purchasequantity; 
purchaseEdit_totalquantity;
  purchaseEdit_purchaseamount;
   purchaseEdit_netamount;
   purchaseEdit_date;
Update_Purchase(updateddata,productname,producttype,providerdetails,quantity,unit,totalamount,paidamount,date,details,id){
  var qunty = parseInt(updateddata.quantity) ;
    var amt = parseInt(updateddata.totalamount);
  
    return new Promise ((resolve, reject) => {
  let sql1 = "SELECT * FROM AddStock WHERE productname = ? AND date = ? ";
	this.db.executeSql(sql1, [productname,date]).then((data) => {
  
          if (data.rows.length > 0) {
            console.log("1row found");
              for (var i = 0; i < data.rows.length; i++) {
                console.log(data.rows.item(i));
                  this.purchaseEdit_id = data.rows.item(i).id;
                  this.purchaseEdit_purchasequantity = parseInt (data.rows.item(i).purchasequantity);
                  this.purchaseEdit_totalquantity = parseInt (data.rows.item(i).totalquantity);
                  this.purchaseEdit_purchaseamount = parseInt (data.rows.item(i).purchaseamount);
                  this.purchaseEdit_netamount = parseInt (data.rows.item(i).netamount);
                  this.purchaseEdit_date=data.rows.item(i).date             
              }
              if(quantity > qunty ){
             var  finalqunt = quantity - qunty;
             console.log("finalqunt==="+finalqunt);
              this.purchaseEdit_purchasequantity =  parseInt(this.purchaseEdit_purchasequantity) + finalqunt;
              this.purchaseEdit_totalquantity = parseInt(this.purchaseEdit_totalquantity) + finalqunt;
             
              }else{
                var  finalqunt1  = qunty - quantity;
              this.purchaseEdit_purchasequantity = parseInt(this.purchaseEdit_purchasequantity)  - finalqunt1;
              this.purchaseEdit_totalquantity = parseInt(this.purchaseEdit_totalquantity)  - finalqunt1;
              }
              if(totalamount>amt){
                var finalAmt = totalamount - amt;
                this.purchaseEdit_purchaseamount = parseInt(this.purchaseEdit_purchaseamount) + finalAmt;
                this.purchaseEdit_netamount = parseInt(this.purchaseEdit_netamount)  + finalAmt;
              }else{
                var finalAmt1 = amt - totalamount;
                this.purchaseEdit_purchaseamount = parseInt(this.purchaseEdit_purchaseamount) -finalAmt1;
                this.purchaseEdit_netamount =  parseInt(this.purchaseEdit_netamount) - finalAmt1;
              }
              console.log( "Editpurchasequantity"+this.purchaseEdit_purchasequantity);
              console.log( "Edittotalquantity"+this.purchaseEdit_totalquantity);
              console.log( ".Editpurchaseamount"+this.purchaseEdit_purchaseamount);
              console.log( "Editnetamount"+this.purchaseEdit_netamount);

              let sql8 = "UPDATE AddStock SET purchasequantity =? ,totalquantity = ?,purchaseamount =? ,netamount =? WHERE id= ? ";
              this.db.executeSql(sql8,[this.purchaseEdit_purchasequantity, this.purchaseEdit_totalquantity,this.purchaseEdit_purchaseamount,this.purchaseEdit_netamount,this.purchaseEdit_id]).then((data) =>{
              console.log("Update done"+data);
                resolve(data);
               }, (error) => {
               reject(error);
             });
            
          }else{
      }
      resolve(data);
      },(error) => {
          reject(error);
    })
      //----------------
      let sql8 = "UPDATE addpurchaseitem SET productname = ?,producttype = ?,providerdetails = ?,quantity = ?,unit =? ,totalamount = ?,paidamount = ?,date = ?,details = ? WHERE id=? ";
            this.db.executeSql(sql8,[productname,producttype,providerdetails,quantity,unit,totalamount,paidamount,date,details,id]).then((data) =>{
              console.log("done"+data);
                resolve(data);
              }, (error) => {
            reject(error);
          });
        });
} 


//delete


purchase_Delid;
 purchase_Delquantity;
  purchase_Deltotalquantity;
purchase_Delamount;
 purchase_Delnetamount; 
purchase_Deldate;
Deletepurchaseitem(item,id){
  var prdnm =item.productname;
  var dat = item.date;
  var qunty = item.quantity;
  var amt = item.totalamount;
  return new Promise ((resolve, reject) => {  
	let sql1 = "SELECT id, purchasequantity ,totalquantity ,purchaseamount ,netamount FROM AddStock WHERE productname = ? AND date = ? ";
	this.db.executeSql(sql1, [prdnm,dat]).then((data) => {
          if (data.rows.length > 0) {
              for (var i = 0; i < data.rows.length; i++) {
                console.log("delete ho jaae");
                console.log(data.rows.item(i));
                  this.purchase_Delid = data.rows.item(i).id;
                  this.purchase_Delquantity = data.rows.item(i).purchasequantity;
                  this.purchase_Deltotalquantity = data.rows.item(i).totalquantity;
                  this.purchase_Delamount = data.rows.item(i).purchaseamount;
                  this.purchase_Delnetamount = data.rows.item(i).netamount;
                  this.purchase_Deldate=data.rows.item(i).date             
              }
              console.log("id ="+this.purchase_Delid,this.purchase_Delquantity, this.purchase_Delnetamount); 

              this.purchase_Delquantity =  this.purchase_Delquantity - qunty;
              this.purchase_Deltotalquantity = this.purchase_Deltotalquantity- qunty;
              this.purchase_Delamount =  this.purchase_Delamount-amt;
              this.purchase_Delnetamount = this.purchase_Delnetamount - amt;

              console.log( "Delpurchasequantity"+this.purchase_Delquantity);
              console.log( "Deltotalquantity"+this.purchase_Deltotalquantity);
              console.log( ".Delpurchaseamount"+this.purchase_Delamount);
              console.log( "Delnetamount"+this.purchase_Delnetamount);

              let sql8 = "UPDATE AddStock SET purchasequantity =? ,totalquantity = ?,purchaseamount =? ,netamount =? WHERE id= ? ";
              this.db.executeSql(sql8,[this.purchase_Delquantity, this.purchase_Deltotalquantity,this.purchase_Delamount,this.purchase_Delnetamount,this.purchase_Delid]).then((data) =>{
              console.log("Update done"+data);
                resolve(data);
               }, (error) => {
               reject(error);
             });
   
          }else{
      }
      resolve(data);
      },(error) => {
          reject(error);
    })
	
	//---------------
	let sql2 = "DELETE FROM  addpurchaseitem WHERE id = ?";
      this.db.executeSql(sql2,[id]).then((data) =>{ 
            resolve(data);
          }, (error) => {
            reject(error);
          });
 });
	
	}
  

  
// Alfhia update  sold item   
   solddata1;
solditem(item){
     this.solddata1 =item;
}
Returnsolddata(){
     return this.solddata1;
 
} 
   //Alfiya Update sold query
update_sold_item(id,productname,customername,producttype,quantity,totalamount,date,customerdetails){
     console.log(id,productname,customername,producttype,quantity,totalamount,date,customerdetails);
      return new Promise ((resolve, reject) => {
       console.log(id,productname,customername,producttype,quantity,totalamount,date,customerdetails);
         let sql5 = "UPDATE addsolditem SET productname = ?,customername = ?,producttype = ?,quantity = ? ,totalamount = ?,date = ?,customerdetails = ? WHERE id=? ";
          console.log(id,productname,customername,producttype,quantity,totalamount,date,customerdetails);
            this.db.executeSql(sql5, [id,productname,customername,producttype,quantity,totalamount,date,customerdetails]).then((data) =>{
              console.log("Done"+data);
                resolve(data);
            }, (error) => {
          reject(error);
        });
    });
} 

//Alfiya Delete Sold Query
Deletesolditem(id){
  return new Promise ((resolve, reject) => {
    let sql2 = "DELETE FROM addsolditem  WHERE id = ?";
    this.db.executeSql(sql2,[id]).then((data) =>{ 
          resolve(data);
        }, (error) => {        
          reject(error);
      });
  });
}
  //Chandu
EditData;
EditProduction(item){
    this.EditData =item;
}
RrturnEditDara(){
    return this.EditData;
}

// update

Editid;Editproducequantity; Edittotalquantity;
  Editproduceamount; Editnetamount;Editdate;
  Update_producation(UpdateDate,id,productname,producttype,quantity,unit,amount,date){
    var qunty = parseInt(UpdateDate.quantity) ;
    var amt = parseInt(UpdateDate.amount);
  
    return new Promise ((resolve, reject) => {
  let sql1 = "SELECT id, producequantity ,totalquantity ,produceamount ,netamount FROM AddStock WHERE productname = ? AND date = ? ";
	this.db.executeSql(sql1, [productname,date]).then((data) => {
          if (data.rows.length > 0) {
              for (var i = 0; i < data.rows.length; i++) {
                console.log(data.rows.item(i));
                  this.Editid = data.rows.item(i).id;
                  this.Editproducequantity = parseInt(data.rows.item(i).producequantity) ;
                  this.Edittotalquantity = parseInt(data.rows.item(i).totalquantity) ;
                  this.Editproduceamount = parseInt(data.rows.item(i).produceamount) ;
                  this.Editnetamount = parseInt(data.rows.item(i).netamount) ;
                  this.Editdate=data.rows.item(i).date             
              }
              
              if(quantity > qunty ){
             var  finalqunt = quantity - qunty;
             console.log("finalqunt==="+finalqunt);
              this.Editproducequantity =  parseInt(this.Editproducequantity) + finalqunt;
              this.Edittotalquantity = parseInt(this.Edittotalquantity) + finalqunt;
             
              }else{
                var  finalqunt1  = qunty - quantity;
              this.Editproducequantity = parseInt(this.Editproducequantity)  - finalqunt1;
              this.Edittotalquantity = parseInt(this.Edittotalquantity)  - finalqunt1;
              }
              if(amount>amt){
                var finalAmt = amount - amt;
                this.Editproduceamount = parseInt(this.Editproduceamount) + finalAmt;
                this.Editnetamount = parseInt(this.Editnetamount)  + finalAmt;
              }else{
                var finalAmt1 = amt - amount;
                this.Editproduceamount = parseInt(this.Editproduceamount) -finalAmt1;
                this.Editnetamount =  parseInt(this.Editnetamount) - finalAmt1;
              }
              console.log( "Editproducequantity"+this.Editproducequantity);
              console.log( "Edittotalquantity"+this.Edittotalquantity);
              console.log( ".Editproduceamount"+this.Editproduceamount);
              console.log( "Editnetamount"+this.Editnetamount);

              let sql8 = "UPDATE AddStock SET producequantity =? ,totalquantity = ?,produceamount =? ,netamount =? WHERE id= ? ";
              this.db.executeSql(sql8,[this.Editproducequantity, this.Edittotalquantity,this.Editproduceamount,this.Editnetamount,this.Editid]).then((data) =>{
              console.log("Update done"+data);
                resolve(data);
               }, (error) => {
               reject(error);
             });
            
          }else{
      }
      resolve(data);
      },(error) => {
          reject(error);
    })
      //----------------
    let sql4 = "UPDATE addnewproduction SET productname = ?,producttype = ?,quantity = ?,unit = ?,amount = ?,date = ? WHERE id=? ";
    this.db.executeSql(sql4, [productname,producttype,quantity,unit,amount,date,id]).then((data) =>{
        resolve(data);
      }, (error) => {
        reject(error);
      });
    });
}

//Alfiiya Sold Summary

Sold_Summary(date1,date2){
      console.log(date1,date2);
      return new Promise ((resolve, reject) => {
        let sql5 = "SELECT * FROM addsolditem WHERE date BETWEEN ? AND ? ORDER BY id DESC ";
          this.db.executeSql(sql5, [date1,date2]).then((data) => {
            console.log("Data" +data);
            let arrayUsers = [];
            if (data.rows.length > 0) {
              for (var i = 0; i < data.rows.length; i++) {
                arrayUsers.push({
                  id: data.rows.item(i).id,
                  productname: data.rows.item(i).productname,
                  customername: data.rows.item(i).customername,
                  quantity: data.rows.item(i).quantity,
                  unit: data.rows.item(i).unit,
                  totalamount: data.rows.item(i).totalamount,
                  paidamount: data.rows.item(i).paidamount,
                  date: data.rows.item(i).date,
                  customerdetails: data.rows.item(i).customerdetails
                });            
              }          
            }
            resolve(arrayUsers);
          }, (error) => {
            reject(error);
        })
    });
}

//Alfiya Purchase Sumaary
Purchase_Summary(date1,date2){
        console.log(date1,date2);
        return new Promise ((resolve, reject) => {
          let sql5 = "SELECT * FROM addpurchaseitem WHERE date BETWEEN ? AND ? ORDER BY id DESC ";
            this.db.executeSql(sql5, [date1,date2]).then((data) => {
              console.log("Data" +data);
              let arrayUsers = [];
              if (data.rows.length > 0) {
                for (var i = 0; i < data.rows.length; i++) {
                  arrayUsers.push({
                    id: data.rows.item(i).id,
                    productname: data.rows.item(i).productname,
                    producttype: data.rows.item(i).producttype,
                    providerdetails: data.rows.item(i).providerdetails,
                    quantity: data.rows.item(i).quantity,
                    unit: data.rows.item(i).unit,
                    totalamount: data.rows.item(i).totalamount,
                    paidamount: data.rows.item(i).paidamount,
                    date: data.rows.item(i).date,
                    details: data.rows.item(i).details
                  });            
                }          
              }
              resolve(arrayUsers);
            }, (error) => {
              reject(error);
        })
    });
}

//Chandu Select Summary
Select_Summary(date1,date2){
      console.log(date1,date2);
      return new Promise ((resolve, reject) => {
        let sql5 = "SELECT * FROM addnewproduction WHERE date BETWEEN ? AND ?";
          this.db.executeSql(sql5, [date1,date2]).then((data) => {
            console.log("Data" +data);
            let arrayUsers = [];
            if (data.rows.length > 0) {
              for (var i = 0; i < data.rows.length; i++) {
                arrayUsers.push({
                  id: data.rows.item(i).id,
                  productname: data.rows.item(i).productname,
                  producttype: data.rows.item(i).producttype,
                  quantity: data.rows.item(i).quantity,
                  unit: data.rows.item(i).unit,
                  amount: data.rows.item(i).amount,
                  date: data.rows.item(i).date
                });            
              }          
            }
            resolve(arrayUsers);
          }, (error) => {
            reject(error);
        })
  });

}

// yogesh
Delete_Employee(id){
  console.log(id);
  return new Promise ((resolve, reject) => {
    let sql2 = "DELETE FROM addnewemployee  WHERE id = ?";
    this.db.executeSql(sql2,[id]).then((data) =>{ 
          resolve(data);
        }, (error) => {
         
          reject(error);
        });
    });
  }
  empdata;
  Show_employee(item){
   this.empdata=item;
  }
  returnempdata(){
    console.log(this.empdata);
    return this.empdata;
    
  }

//charu attendence
ViewAttendence(date){
  console.log(date);
  return new Promise ((resolve, reject) => {
    let sql5 = "SELECT * FROM attendance WHERE date =?";
      this.db.executeSql(sql5, [date]).then((data) => {
        console.log("Data" +data);
        let arrayUsers = [];
        if (data.rows.length > 0) {
          for (var i = 0; i < data.rows.length; i++) {
            arrayUsers.push({
              id: data.rows.item(i).id,
              employeename: data.rows.item(i).employeename,
              attendancestatus: data.rows.item(i).attendancestatus,
              date: data.rows.item(i).date,
            });            
          }          
        }
        resolve(arrayUsers);
      }, (error) => {
        reject(error);
      })
  });
}
//yogesh
Update_employee(id,employeename,contact,email,salary,mode,address){
  var Emailid;
  var mobileno;
  return new Promise ((resolve, reject) => {
    let sql5="SELECT * from addnewemployee WHERE contact = ?";
    this.db.executeSql(sql5, [contact]).then(async (data)=>{
      if(data.rows.length>0){
        for(var i=0;i<data.rows.length;i++){
          mobileno = data.rows.item(i).contact;
          Emailid=data.rows.item(i).email;
        }

        if(Emailid==email && mobileno==contact){

          let sql4 = "UPDATE addnewemployee SET employeename = ?,contact = ?,email = ?,salary = ?,mode = ?,address = ? WHERE id=? ";
          this.db.executeSql(sql4, [employeename,contact,email,salary,mode,address,id]).then((data) =>{    
           resolve(data);
          }, (error) => {
   
           reject(error);
          });

        
      }
      else{
        const toast = await this.toastcontroller.create({
         message: 'User cant change mobile number and email id.',
         duration: 2000
       });
      toast.present();
  
}}
}) 

});
}

//yogesh

Select_attendance(date1,employee){
  console.log(date1,employee);
  return new Promise ((resolve, reject) => {
    let sql5 = "SELECT * FROM attendance WHERE date =? AND employeename =?";
      this.db.executeSql(sql5, [date1,employee]).then((data) => {
        console.log("Data" +data);
        let arrayUsers = [];
        if (data.rows.length > 0) {
          for (var i = 0; i < data.rows.length; i++) {
            arrayUsers.push({
              id: data.rows.item(i).id,
              employeename: data.rows.item(i).employeename,
              attendancestatus: data.rows.item(i).attendancestatus
            });            
          }          
        }
        else{alert("data not found");}
        resolve(arrayUsers);
      }, (error) => {
        reject(error);
      })
  });
}

  //yogesh
  GetViewEmployee(name){
    console.log( "Name ="+name);
   return new Promise ((resolve, reject) => {
     this.db.executeSql("SELECT * FROM attendance WHERE employeename = ?", [name]).then((data) => {
       let arrayUsers = [];
       if (data.rows.length > 0) {
         for (var i = 0; i < data.rows.length; i++) {
           arrayUsers.push({
             id: data.rows.item(i).id,
             attendancestatus: data.rows.item(i).attendancestatus,
             employeename: data.rows.item(i).employeename,
             date: data.rows.item(i).date
           });
           for(let j=0;j<=arrayUsers.length;j++){
             console.log(arrayUsers);
           } 
         }          
       }
       resolve(arrayUsers);
     }, (error) => {
       reject(error);
     })
   })
 }
  
//Get attendence charu
GetAttendance(){
    return new Promise ((resolve, reject) => {
      this.db.executeSql("SELECT * FROM addnewemployee", []).then((data) => {
        let arrayUsers = [];
        if (data.rows.length > 0) {
          for (var i = 0; i < data.rows.length; i++) {
            arrayUsers.push({
              id: data.rows.item(i).id,
              employeename: data.rows.item(i).productname,
              contact: data.rows.item(i).producttype,
              email: data.rows.item(i).quantity,
              salary: data.rows.item(i).unit,
              mode: data.rows.item(i).amount,
              address: data.rows.item(i).date
            });            
          }          
        }
        resolve(arrayUsers);
      }, (error) => {
        reject(error);
      })
    })
}
 //Mona Get Produced data
GetProductionFinal(From,To){
    return new Promise ((resolve, reject) => {
      this.db.executeSql("SELECT SUM(quantity) AS totalproductionquantity , COUNT(productname) AS productioncount ,SUM(amount) AS totalproductionamount FROM addnewproduction where date BETWEEN '"+From+"' AND '"+To+"' ", []).then((data) => {
  let Users=[];
  if (data.rows.length > 0) {
    this.totalproductionquantity = parseInt(data.rows.item(0).totalproductionquantity);
    this.totalproductionamount = parseInt(data.rows.item(0).totalproductionamount);
    this.productioncount = parseInt(data.rows.item(0).productioncount);
    for (var i = 0; i < data.rows.length; i++) {  
      
      console.log("this.count1");
    Users.push({
       totalproductionamount: data.rows.item(i).totalproductionamount,
       totalproductionquantity:data.rows.item(i).totalproductionquantity,
        productioncount: data.rows.item(i).productioncount,
        
      });  
    }
      console.log(this.productioncount);
      console.log(this.totalproductionamount);
      console.log(this.totalproductionquantity);                   
  }
  resolve(Users);

  }, (error) => {
    reject(error);
    })
  })
}


//Mona Get purchase Query
GetPurchasedFinal(From,To){
  return new Promise ((resolve, reject) => {
    this.db.executeSql("SELECT SUM(quantity) AS totalpurchasequantity , COUNT( productname) AS purchasecount ,SUM(totalamount) AS totalpurchaseamount FROM addpurchaseitem where date BETWEEN '"+From+"' AND '"+To+"' ", []).then((data) => {
      let Users=[];
        if (data.rows.length > 0) {
          this.totalpurchasequantity = parseInt(data.rows.item(0).totalpurchasequantity);
          this.totalpurchaseamount = parseInt(data.rows.item(0).totalpurchaseamount);
          this.purchasecount = parseInt(data.rows.item(0).purchasecount);
            for (var i = 0; i < data.rows.length; i++) {  
              console.log("this.count1");
            Users.push({
            totalpurchaseamount: data.rows.item(i).totalpurchaseamount,
            totalpurchasequantity:data.rows.item(i).totalpurchasequantity,
              purchasecount: data.rows.item(i).purchasecount,
      
          });  
        } 
        console.log(this.purchasecount);
        console.log(this.totalpurchaseamount);
        console.log(this.totalpurchasequantity);                   
    }
    resolve(Users);
    }, (error) => {
      reject(error);
    })
  })
}

// //Mona Get Sold Query
private totalsoldquantity=0;
private totalsoldamount=0;
private soldcount=0;
GetSoldFinal(From,To){
  return new Promise ((resolve, reject) => {
    this.db.executeSql("SELECT SUM(quantity) AS totalsoldquantity , COUNT(productname) AS soldcount ,SUM(totalamount) AS totalsoldamount FROM addsolditem where date BETWEEN '"+From+"' AND '"+To+"' ", []).then((data) => {
    let Users=[];
      if (data.rows.length > 0) {
        this.totalsoldquantity = parseInt(data.rows.item(0).totalsoldquantity);
        this.totalsoldamount = parseInt(data.rows.item(0).totalsoldamount);
        this.soldcount = parseInt(data.rows.item(0).soldcount);
        for (var i = 0; i < data.rows.length; i++) {  
          
          console.log("this.count1");
        Users.push({
          totalsoldamount: data.rows.item(i).totalsoldamount,
          totalsoldquantity:data.rows.item(i).totalsoldquantity,
          soldcount: data.rows.item(i).soldcount,
            
          });  
        }
          console.log(this.soldcount);
          console.log(this.totalsoldamount);
          console.log(this.totalsoldquantity);                   
      }
      resolve(Users);

    }, (error) => {
    reject(error);
    })
  })
}

//Mona Expense query
totalexpenseamount=0;
GetExpenseFinal(From,To){
  return new Promise ((resolve, reject) => {
    
    this.db.executeSql("SELECT SUM(expensesamount) AS totalexpenseamount FROM addotherexpenses where expensesdate BETWEEN '"+From+"' AND '"+To+"' ", []).then((data) => {
      let Users=[];
      if (data.rows.length > 0) {
      this.totalexpenseamount = parseInt(data.rows.item(0).totalexpenseamount);
      for (var i = 0; i < data.rows.length; i++) {  
      Users.push({
        totalexpenseamount: data.rows.item(i).totalexpenseamount,
          
        });  
      }
        console.log(this.totalexpenseamount);
                    
    }
    resolve(Users);
          }, (error) => {
          reject(error);
    })
  })
}


   //sonam stock info
   private finalQuantity=0;
   private finalAmount=0;
   GetStockInfo(From){
    return new Promise ((resolve, reject) => {
      this.db.executeSql("SELECT SUM(totalquantity) AS finalQuantity, SUM(netamount) AS finalAmount , producttype FROM AddStock where date = '"+From+"' GROUP BY producttype ", []).then(async (data) => {
        let StockUsers = [];
        if (data.rows.length > 0) {
          this.finalQuantity = parseInt(data.rows.item(0).finalQuantity);
          console.log(this.finalQuantity);
          this.finalAmount = parseInt(data.rows.item(0).finalAmount);
          for (var i = 0; i < data.rows.length; i++) {
            console.log("sonam stock");
            StockUsers.push({
              producttype:data.rows.item(i).producttype,
              finalQuantity: data.rows.item(i).finalQuantity,
              finalAmount:data.rows.item(i).finalAmount,
            }); 
            console.log("gusss gayeeeeeeeeee");
            console.log(this.producttype);
          } 
          console.log(StockUsers);         
        }else{
          const toast = await this.toastcontroller.create({
            message: 'No Data Found',
            duration: 2000
          });
          toast.present();
        }
        resolve(StockUsers);
      }, (error) => {
        reject(error);
      })
    });
      } 

      //sonam stock details
 GetStockDetails(From,producttype){
  return new Promise ((resolve, reject) => {
    this.db.executeSql("SELECT * FROM AddStock where date = '"+From+"' AND producttype='"+producttype+"'", []).then((data) => {
      let StockDetails = [];
      if (data.rows.length > 0) {
        for (var i = 0; i < data.rows.length; i++) {
          console.log("sonam stock details");
          StockDetails.push({
            id: data.rows.item(i).id,
            productname: data.rows.item(i).productname,
            producttype: data.rows.item(i).producttype,
            totalquantity: data.rows.item(i).totalquantity,
            netamount:data.rows.item(i).netamount,
            producequantity:data.rows.item(i).producequantity,
            purchasequantity:data.rows.item(i).purchasequantity,
            produceamount:data.rows.item(i).produceamount,
            purchaseamount:data.rows.item(i).purchaseamount,
            date: data.rows.item(i).date,
          }); 
        } 
        console.log(StockDetails);         
      }
      resolve(StockDetails);
    }, (error) => {
      reject(error);
    })
  })
    }
    
//     //alfiya sold

 GetSoldDetails(){
  return new Promise ((resolve, reject) => {
    this.db.executeSql("SELECT * FROM AddStock ", []).then((data) => {
      let SoldDetails = [];
      if (data.rows.length > 0) {
        for (var i = 0; i < data.rows.length; i++) {
          console.log("sonam stock details");
          SoldDetails.push({
            id: data.rows.item(i).id,
            productname: data.rows.item(i).productname,
            producttype: data.rows.item(i).producttype,
            totalquantity: data.rows.item(i).totalquantity,
            netamount:data.rows.item(i).netamount,
            producequantity:data.rows.item(i).producequantity,
            purchasequantity:data.rows.item(i).purchasequantity,
            produceamount:data.rows.item(i).produceamount,
            purchaseamount:data.rows.item(i).purchaseamount,
            date: data.rows.item(i).date,
          }); 
        } 
        console.log(SoldDetails);         
      }
      resolve(SoldDetails);
    }, (error) => {
      reject(error);
    })
  })
    }

    //alfiya
    GetSold(productname){
      return new Promise ((resolve, reject) => {
        this.db.executeSql("SELECT * FROM AddStock where  productname='"+productname+"'", []).then((data) => {
          let StockDetails = [];
          if (data.rows.length > 0) {
            for (var i = 0; i < data.rows.length; i++) {
              StockDetails.push({
                id: data.rows.item(i).id,
                productname: data.rows.item(i).productname,
                producttype: data.rows.item(i).producttype,
                totalquantity: data.rows.item(i).totalquantity,
                netamount:data.rows.item(i).netamount,
                producequantity:data.rows.item(i).producequantity,
                purchasequantity:data.rows.item(i).purchasequantity,
                produceamount:data.rows.item(i).produceamount,
                purchaseamount:data.rows.item(i).purchaseamount,
                date: data.rows.item(i).date,
              }); 
            }         
          }
          resolve(StockDetails);
        }, (error) => {
          reject(error);
        })
      })
        }
        //sonam stock sold
       /*  quantity;
        totalamount;
 GetStockSoldDetails(From,producttype){
   console.log("bacha lo");
   console.log(producttype);
  return new Promise ((resolve, reject) => {
    this.db.executeSql("SELECT * FROM addsolditem where date = '"+From+"' AND producttype='"+producttype+"'", []).then((data) => {
      let StockSoldDetails = [];
      if (data.rows.length > 0) {
        for (var i = 0; i < data.rows.length; i++) {
          console.log("sonam stock sold details");
          StockSoldDetails.push({
            id: data.rows.item(i).id,
              productname: data.rows.item(i).productname,
              customername: data.rows.item(i).customername,
              producttype: data.rows.item(i).producttype,
              quantity: data.rows.item(i).quantity,
              totalamount: data.rows.item(i).totalamount,
              date: data.rows.item(i).date,
              customerdetails: data.rows.item(i).customerdetails
          }); 
        } 
        
        console.log(StockSoldDetails);         
      }
      resolve(StockSoldDetails);
    }, (error) => {
      reject(error);
    })
  })
    } */
}
